                        Matthew Henry's
             Concise Commentary on the Whole Bible

                  Public Domain--Copy Freely.

This text matches the printed edition as published by Moody
Press, 28th printing, no Copyright displayed. ISBN:
0-8024-5190-X. This text was created from an existing electronic
copy, with roughly 1200 errors corrected. The current files can
be found on:

        Bible Foundation BBS,
        602-789-7040 (14.4 kbs)

If any errors are located, please notify me at the above BBS, or
at:

        Mark Fuller
        1129 E. Loyola Dr.
        Tempe, Az. 85282
        (602) 829-8542

